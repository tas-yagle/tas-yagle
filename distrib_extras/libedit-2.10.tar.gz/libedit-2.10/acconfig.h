/*
 * Copyright (C) 2001 LAAS/CNRS 
 *
 * $LAAS: acconfig.h,v 1.2 2003/07/06 15:47:21 mallet Exp $
 */
#ifndef LIBEDIT_CONFIG_H
#define LIBEDIT_CONFIG_H

@TOP@
@BOTTOM@

/* Define if you have the sig_t typedef.  */
#undef HAVE_SIG_T

/* Define if you have the issetugid() syscall.  */
#undef HAVE_ISSETUGID

#ifdef HAVE_SYS_CDEFS_H
# include <sys/cdefs.h>
#else
# ifdef STDC_HEADERS
#  define __P(protos)	protos	/* full-blown ANSI C */
# else
#  define __P(protos)	()	/* traditional C preprocessor */
# endif /* STDC_HEADERS */
#endif /* HAVE_SYS_CDEFS_H */

#ifndef __RCSID
#ifdef __GNUC__
#define __RCSID(id) static const char rcsid[] __attribute__((__unused__)) = id
#else
#define __RCSID(id) static const char rcsid[] = id
#endif /* __GNUC__ */
#endif

#ifndef HAVE_SIG_T
typedef RETSIGTYPE (*sig_t) __P((int));	/* type of signal function */
#endif /* HAVE_SIG_T */

#ifndef HAVE_ISSETUGID
int issetugid(void);
#endif /* HAVE_ISSETUGID */

#ifndef HAVE_STRLCPY
# include <stdlib.h>
size_t	strlcpy(char *dst, const char *src, size_t size);
#endif /* HAVE_STRLCPY */

#ifndef HAVE_STRLCAT
# include <stdlib.h>
size_t	strlcat(char *dst, const char *src, size_t size);
#endif /* HAVE_STRLCAT */

#ifndef HAVE_FGETLN
# include <stdio.h>
char * fgetln(FILE *stream, size_t *len);
#endif /* HAVE_FGETLN */

#include "sys.h"

#endif /* LIBEDIT_CONFIG_H */
