/*	$LAAS: libedit.h,v 1.1 2005/08/23 16:13:52 matthieu Exp $ */
/*
 * Copyright (c) 2005 CNRS/LAAS
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
#ifndef _LIBEDIT_H
#define _LIBEDIT_H

#include "config.h"

#include <sys/types.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>

#include <arpa/ftp.h>
#include <arpa/inet.h>

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pwd.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

#if HAVE_DIRENT_H
# include <dirent.h>
#else
# define dirent direct
# if HAVE_SYS_NDIR_H
#  include <sys/ndir.h>
# endif
# if HAVE_SYS_DIR_H
#  include <sys/dir.h>
# endif
# if HAVE_NDIR_H
#  include <ndir.h>
# endif
#endif

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#if HAVE_SYS_SYSLIMITS_H
# include <sys/syslimits.h>
#endif

#if HAVE_ERR_H
# include <err.h>
#endif

#if HAVE_PATHS_H
# include <paths.h>
#endif
#ifndef _PATH_BSHELL
#define _PATH_BSHELL	"/bin/sh"
#endif
#ifndef _PATH_TMP
#define _PATH_TMP	"/tmp/"
#endif

#if HAVE_TERMCAP_H
# include <termcap.h>
#else
int	 tgetent(char *, const char *);
char	*tgetstr(const char *, char **);
int	 tgetflag(const char *);
int	 tgetnum(const char *);
char	*tgoto(const char *, int, int);
void	 tputs(const char *, int, int (*)(int));
#endif


#if defined(HAVE_VIS_H) && defined(HAVE_STRVIS) && defined(HAVE_STRUNVIS)
# include <vis.h>
#else
# include "el_vis.h"
#endif


#if !defined(HAVE_D_NAMLEN)
# define DIRENT_MISSING_D_NAMLEN
#endif

#if !defined(HAVE_H_ERRNO_D)
extern int	h_errno;
#endif
#define HAVE_H_ERRNO	1		/* XXX: an assumption for now... */

#if !defined(HAVE_FCLOSE_D)
int	fclose(FILE *);
#endif

#if !defined(HAVE_DIRNAME_D)
char	*dirname(char *);
#endif

#if !defined(HAVE_ERR)
void	err(int, const char *, ...);
void	errx(int, const char *, ...);
void	warn(const char *, ...);
void	warnx(const char *, ...);
#endif

#if !defined(HAVE_FGETLN)
char   *fgetln(FILE *, size_t *);
#endif

#if !defined(HAVE_MKSTEMP)
int	mkstemp(char *);
#endif

#if !defined(HAVE_SNPRINTF)
int	snprintf(char *, size_t, const char *, ...);
#endif

#if !defined(HAVE_STRDUP)
char   *strdup(const char *);
#endif

#if !defined(HAVE_STRERROR)
char   *strerror(int);
#endif

#if !defined(HAVE_HSTRERROR)
char   *strerror(int);
#endif

#if !defined(HAVE_STRLCAT)
size_t	strlcat(char *, const char *, size_t);
#endif

#if !defined(HAVE_STRLCPY)
size_t	strlcpy(char *, const char *, size_t);
#endif

#endif
