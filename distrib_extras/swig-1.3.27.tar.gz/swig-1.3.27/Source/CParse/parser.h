/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ID = 258,
     HBLOCK = 259,
     POUND = 260,
     STRING = 261,
     INCLUDE = 262,
     IMPORT = 263,
     INSERT = 264,
     CHARCONST = 265,
     NUM_INT = 266,
     NUM_FLOAT = 267,
     NUM_UNSIGNED = 268,
     NUM_LONG = 269,
     NUM_ULONG = 270,
     NUM_LONGLONG = 271,
     NUM_ULONGLONG = 272,
     TYPEDEF = 273,
     TYPE_INT = 274,
     TYPE_UNSIGNED = 275,
     TYPE_SHORT = 276,
     TYPE_LONG = 277,
     TYPE_FLOAT = 278,
     TYPE_DOUBLE = 279,
     TYPE_CHAR = 280,
     TYPE_WCHAR = 281,
     TYPE_VOID = 282,
     TYPE_SIGNED = 283,
     TYPE_BOOL = 284,
     TYPE_COMPLEX = 285,
     TYPE_TYPEDEF = 286,
     TYPE_RAW = 287,
     LPAREN = 288,
     RPAREN = 289,
     COMMA = 290,
     SEMI = 291,
     EXTERN = 292,
     INIT = 293,
     LBRACE = 294,
     RBRACE = 295,
     PERIOD = 296,
     CONST_QUAL = 297,
     VOLATILE = 298,
     REGISTER = 299,
     STRUCT = 300,
     UNION = 301,
     EQUAL = 302,
     SIZEOF = 303,
     MODULE = 304,
     LBRACKET = 305,
     RBRACKET = 306,
     ILLEGAL = 307,
     CONSTANT = 308,
     NAME = 309,
     RENAME = 310,
     NAMEWARN = 311,
     EXTEND = 312,
     PRAGMA = 313,
     FEATURE = 314,
     VARARGS = 315,
     ENUM = 316,
     CLASS = 317,
     TYPENAME = 318,
     PRIVATE = 319,
     PUBLIC = 320,
     PROTECTED = 321,
     COLON = 322,
     STATIC = 323,
     VIRTUAL = 324,
     FRIEND = 325,
     THROW = 326,
     CATCH = 327,
     USING = 328,
     NAMESPACE = 329,
     NATIVE = 330,
     INLINE = 331,
     TYPEMAP = 332,
     EXCEPT = 333,
     ECHO = 334,
     APPLY = 335,
     CLEAR = 336,
     SWIGTEMPLATE = 337,
     FRAGMENT = 338,
     WARN = 339,
     LESSTHAN = 340,
     GREATERTHAN = 341,
     MODULO = 342,
     DELETE_KW = 343,
     TYPES = 344,
     PARMS = 345,
     NONID = 346,
     DSTAR = 347,
     DCNOT = 348,
     TEMPLATE = 349,
     OPERATOR = 350,
     COPERATOR = 351,
     PARSETYPE = 352,
     PARSEPARM = 353,
     CAST = 354,
     LOR = 355,
     LAND = 356,
     OR = 357,
     XOR = 358,
     AND = 359,
     RSHIFT = 360,
     LSHIFT = 361,
     MINUS = 362,
     PLUS = 363,
     SLASH = 364,
     STAR = 365,
     LNOT = 366,
     NOT = 367,
     UMINUS = 368,
     DCOLON = 369
   };
#endif
#define ID 258
#define HBLOCK 259
#define POUND 260
#define STRING 261
#define INCLUDE 262
#define IMPORT 263
#define INSERT 264
#define CHARCONST 265
#define NUM_INT 266
#define NUM_FLOAT 267
#define NUM_UNSIGNED 268
#define NUM_LONG 269
#define NUM_ULONG 270
#define NUM_LONGLONG 271
#define NUM_ULONGLONG 272
#define TYPEDEF 273
#define TYPE_INT 274
#define TYPE_UNSIGNED 275
#define TYPE_SHORT 276
#define TYPE_LONG 277
#define TYPE_FLOAT 278
#define TYPE_DOUBLE 279
#define TYPE_CHAR 280
#define TYPE_WCHAR 281
#define TYPE_VOID 282
#define TYPE_SIGNED 283
#define TYPE_BOOL 284
#define TYPE_COMPLEX 285
#define TYPE_TYPEDEF 286
#define TYPE_RAW 287
#define LPAREN 288
#define RPAREN 289
#define COMMA 290
#define SEMI 291
#define EXTERN 292
#define INIT 293
#define LBRACE 294
#define RBRACE 295
#define PERIOD 296
#define CONST_QUAL 297
#define VOLATILE 298
#define REGISTER 299
#define STRUCT 300
#define UNION 301
#define EQUAL 302
#define SIZEOF 303
#define MODULE 304
#define LBRACKET 305
#define RBRACKET 306
#define ILLEGAL 307
#define CONSTANT 308
#define NAME 309
#define RENAME 310
#define NAMEWARN 311
#define EXTEND 312
#define PRAGMA 313
#define FEATURE 314
#define VARARGS 315
#define ENUM 316
#define CLASS 317
#define TYPENAME 318
#define PRIVATE 319
#define PUBLIC 320
#define PROTECTED 321
#define COLON 322
#define STATIC 323
#define VIRTUAL 324
#define FRIEND 325
#define THROW 326
#define CATCH 327
#define USING 328
#define NAMESPACE 329
#define NATIVE 330
#define INLINE 331
#define TYPEMAP 332
#define EXCEPT 333
#define ECHO 334
#define APPLY 335
#define CLEAR 336
#define SWIGTEMPLATE 337
#define FRAGMENT 338
#define WARN 339
#define LESSTHAN 340
#define GREATERTHAN 341
#define MODULO 342
#define DELETE_KW 343
#define TYPES 344
#define PARMS 345
#define NONID 346
#define DSTAR 347
#define DCNOT 348
#define TEMPLATE 349
#define OPERATOR 350
#define COPERATOR 351
#define PARSETYPE 352
#define PARSEPARM 353
#define CAST 354
#define LOR 355
#define LAND 356
#define OR 357
#define XOR 358
#define AND 359
#define RSHIFT 360
#define LSHIFT 361
#define MINUS 362
#define PLUS 363
#define SLASH 364
#define STAR 365
#define LNOT 366
#define NOT 367
#define UMINUS 368
#define DCOLON 369




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 1242 "parser.y"
typedef union YYSTYPE {
  char  *id;
  List  *bases;
  struct Define {
    String *val;
    String *rawval;
    int     type;
    String *qualifier;
    String *bitfield;
    Parm   *throws;
    String *throw;
  } dtype;
  struct {
    char *type;
    char *filename;
    int   line;
  } loc;
  struct {
    char      *id;
    SwigType  *type;
    String    *defarg;
    ParmList  *parms;
    short      have_parms;
    ParmList  *throws;
    String    *throw;
  } decl;
  Parm         *tparms;
  struct {
    String     *op;
    Hash       *kwargs;
  } tmap;
  struct {
    String     *type;
    String     *us;
  } ptype;
  SwigType     *type;
  String       *str;
  Parm         *p;
  ParmList     *pl;
  int           ivalue;
  Node         *node;
} YYSTYPE;
/* Line 1249 of yacc.c.  */
#line 307 "y.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



